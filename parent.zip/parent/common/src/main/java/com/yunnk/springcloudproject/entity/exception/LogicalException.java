package com.yunnk.springcloudproject.entity.exception;

/**
 * @author huangyigang
 */
public class LogicalException extends RuntimeException{
    public LogicalException(String message) {
        super(message);
    }
}
