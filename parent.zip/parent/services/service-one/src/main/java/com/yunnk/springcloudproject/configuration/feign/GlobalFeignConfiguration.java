package com.yunnk.springcloudproject.configuration.feign;

/**
 * 全局feign配置类，用于配置文件无法实现的全局配置
 * @author huangyigang
 */
public class GlobalFeignConfiguration {

}
