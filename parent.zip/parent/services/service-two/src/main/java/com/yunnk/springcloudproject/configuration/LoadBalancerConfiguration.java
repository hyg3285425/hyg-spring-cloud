package com.yunnk.springcloudproject.configuration;

import org.springframework.context.annotation.Configuration;

/**
 * 定义LoadBalancer的全局配置
 * @author huangyigang
 */
@Configuration
public class LoadBalancerConfiguration {

}
