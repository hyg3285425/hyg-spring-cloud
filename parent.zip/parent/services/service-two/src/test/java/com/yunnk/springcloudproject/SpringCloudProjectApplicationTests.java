package com.yunnk.springcloudproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
